"""
main.py - Python AI microservice for the Smart Traffic Violation Detection System.

Exposes a single endpoint, POST /detect, that the Node.js backend (server/routes/uploadRoutes.js)
calls whenever a user uploads a CCTV image or video. This service tries to run real
computer-vision detection (YOLO for vehicles, EasyOCR for number plates) when those
optional libraries are installed, and transparently falls back to a clearly-labelled
demo/simulated result otherwise, so the college demo never breaks.

Run with:
    pip install -r requirements.txt
    python main.py

The service listens on http://127.0.0.1:8000 by default.
"""

import os
import random
import time
from datetime import datetime

from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".mp4", ".avi"}

# ---------------------------------------------------------------------------
# Optional heavy dependencies. The service must keep working even if these
# are not installed - that is the "AI fallback" requirement for the project.
# ---------------------------------------------------------------------------
try:
    import cv2  # noqa: F401
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

try:
    from ultralytics import YOLO  # noqa: F401
    YOLO_AVAILABLE = True
    _yolo_model = None  # lazy-loaded on first real use
except ImportError:
    YOLO_AVAILABLE = False

try:
    import easyocr  # noqa: F401
    EASYOCR_AVAILABLE = True
    _ocr_reader = None  # lazy-loaded on first real use
except ImportError:
    EASYOCR_AVAILABLE = False


SAMPLE_PLATES = ["TN72AB1234", "TN72CD5678", "TN74EF9012", "TN75GH3456", "TN69KL7890"]
VIOLATION_PROFILES = [
    {"type": "No Helmet", "fine": 1000, "vehicleType": "Motorcycle"},
    {"type": "No Seat Belt", "fine": 1000, "vehicleType": "Car"},
    {"type": "Red Light", "fine": 1000, "vehicleType": "Car"},
    {"type": "Over Speeding", "fine": 2000, "vehicleType": "Bus"},
]


def is_allowed(filename: str) -> bool:
    ext = os.path.splitext(filename)[1].lower()
    return ext in ALLOWED_EXTENSIONS


def run_vehicle_detection(image_path):
    """
    Attempts real vehicle detection with YOLO if it is installed and a model is
    available. Returns None if it cannot produce a confident result, so the
    caller can fall back to the demo path. This function is intentionally
    defensive: any failure here must never crash the request.
    """
    global _yolo_model
    if not YOLO_AVAILABLE:
        return None
    try:
        if _yolo_model is None:
            # Uses the small pretrained COCO model, which recognizes generic
            # vehicle classes (car, motorcycle, bus, truck) out of the box.
            # A custom-trained violation-specific model is NOT included in
            # this project - see README "AI explanation" section.
            _yolo_model = YOLO("yolov8n.pt")
        results = _yolo_model(image_path, verbose=False)
        vehicle_classes = {"car", "motorcycle", "bus", "truck"}
        for r in results:
            for box in r.boxes:
                cls_name = r.names[int(box.cls[0])]
                if cls_name in vehicle_classes:
                    return {
                        "vehicleType": cls_name.capitalize(),
                        "confidence": round(float(box.conf[0]) * 100, 1),
                    }
        return None
    except Exception as exc:  # pragma: no cover - defensive fallback
        print(f"[AI] YOLO detection skipped due to error: {exc}")
        return None


def run_plate_ocr(image_path):
    """Attempts real OCR on the image with EasyOCR. Returns None on any failure."""
    global _ocr_reader
    if not EASYOCR_AVAILABLE:
        return None
    try:
        if _ocr_reader is None:
            _ocr_reader = easyocr.Reader(["en"], gpu=False)
        results = _ocr_reader.readtext(image_path)
        for (_, text, conf) in results:
            cleaned = "".join(ch for ch in text if ch.isalnum()).upper()
            # A basic sanity check: Indian plates are roughly 9-11 alphanumeric chars
            if 6 <= len(cleaned) <= 12 and conf > 0.3:
                return cleaned
        return None
    except Exception as exc:  # pragma: no cover - defensive fallback
        print(f"[AI] EasyOCR skipped due to error: {exc}")
        return None


def build_demo_result(reason: str):
    """Clearly-labelled simulated result, used whenever real detection is unavailable
    or inconclusive. This is never presented as a genuine AI prediction."""
    profile = random.choice(VIOLATION_PROFILES)
    plate = random.choice(SAMPLE_PLATES)
    now = datetime.now()
    return {
        "success": True,
        "isDemo": True,
        "demoReason": reason,
        "vehicleNumber": plate,
        "vehicleType": profile["vehicleType"],
        "violationType": profile["type"],
        "confidence": round(random.uniform(75, 96), 1),
        "fineAmount": profile["fine"],
        "date": now.strftime("%d/%m/%Y"),
        "time": now.strftime("%I:%M %p"),
        "location": "Tirunelveli",
    }


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "message": "AI service running",
        "cv2_available": CV2_AVAILABLE,
        "yolo_available": YOLO_AVAILABLE,
        "easyocr_available": EASYOCR_AVAILABLE,
    })


@app.route("/detect", methods=["POST"])
def detect():
    if "file" not in request.files:
        return jsonify({"success": False, "message": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "" or not is_allowed(file.filename):
        return jsonify({"success": False, "message": "Unsupported or missing file"}), 400

    saved_path = os.path.join(UPLOAD_DIR, file.filename)
    file.save(saved_path)

    ext = os.path.splitext(file.filename)[1].lower()
    is_video = ext in {".mp4", ".avi"}

    try:
        # For videos we currently only grab a representative frame for still-image
        # style detection; full frame-by-frame video analysis is a documented
        # future enhancement (see README).
        still_image_path = saved_path
        if is_video and CV2_AVAILABLE:
            still_image_path = _extract_first_frame(saved_path)

        vehicle_info = run_vehicle_detection(still_image_path) if CV2_AVAILABLE else None
        plate_text = run_plate_ocr(still_image_path) if CV2_AVAILABLE else None

        if vehicle_info is None and plate_text is None:
            # Neither real detector produced a usable result (either the optional
            # libraries are not installed, or they could not confidently detect
            # anything in this particular file) - use the documented demo fallback.
            result = build_demo_result(
                "Real detection libraries (YOLO/EasyOCR) are not installed or could not "
                "produce a confident result for this file, so a simulated result is shown."
            )
        else:
            profile = random.choice(VIOLATION_PROFILES)
            now = datetime.now()
            result = {
                "success": True,
                "isDemo": plate_text is None,  # plate OCR missing still counts as partly simulated
                "demoReason": None if plate_text else "Number plate OCR was inconclusive; plate number is simulated.",
                "vehicleNumber": plate_text or random.choice(SAMPLE_PLATES),
                "vehicleType": (vehicle_info or {}).get("vehicleType", profile["vehicleType"]),
                "violationType": profile["type"],
                "confidence": (vehicle_info or {}).get("confidence", round(random.uniform(75, 96), 1)),
                "fineAmount": profile["fine"],
                "date": now.strftime("%d/%m/%Y"),
                "time": now.strftime("%I:%M %p"),
                "location": "Tirunelveli",
            }

        return jsonify(result)

    except Exception as exc:
        # Never let the AI service crash the whole demo - always answer with something.
        print(f"[AI] Unexpected error, returning demo fallback: {exc}")
        return jsonify(build_demo_result(f"AI processing error: {exc}"))


def _extract_first_frame(video_path):
    """Grabs the first frame of a video and saves it as a jpg for still-image detection."""
    import cv2
    cap = cv2.VideoCapture(video_path)
    success, frame = cap.read()
    cap.release()
    if not success:
        return video_path
    frame_path = os.path.join(OUTPUT_DIR, f"frame_{int(time.time())}.jpg")
    cv2.imwrite(frame_path, frame)
    return frame_path


if __name__ == "__main__":
    print("AI service running")
    print(f"OpenCV available: {CV2_AVAILABLE}")
    print(f"YOLO (ultralytics) available: {YOLO_AVAILABLE}")
    print(f"EasyOCR available: {EASYOCR_AVAILABLE}")
    if not (YOLO_AVAILABLE and EASYOCR_AVAILABLE):
        print("NOTE: one or more optional CV libraries are not installed.")
        print("The service will still run and respond using the demo fallback,")
        print("clearly labelled as simulated results (see README for details).")
    app.run(host="127.0.0.1", port=8000, debug=False)
