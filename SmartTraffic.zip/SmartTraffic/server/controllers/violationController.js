const Violation = require("../models/Violation");

// GET /api/violations  (supports ?vehicleNumber=&violationType=&status=&page=&limit=)
exports.getViolations = async (req, res) => {
  try {
    const { vehicleNumber, violationType, status, page = 1, limit = 10 } = req.query;
    const filter = {};

    if (vehicleNumber) filter.vehicleNumber = { $regex: vehicleNumber, $options: "i" };
    if (violationType && violationType !== "All") filter.violationType = violationType;
    if (status && status !== "All") filter.status = status;

    const skip = (Number(page) - 1) * Number(limit);
    const [violations, total] = await Promise.all([
      Violation.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Violation.countDocuments(filter),
    ]);

    res.json({
      success: true,
      violations,
      total,
      page: Number(page),
      pages: Math.max(1, Math.ceil(total / Number(limit))),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not fetch violations", error: err.message });
  }
};

exports.getViolationById = async (req, res) => {
  try {
    const violation = await Violation.findById(req.params.id);
    if (!violation) return res.status(404).json({ success: false, message: "Violation not found" });
    res.json({ success: true, violation });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not fetch violation", error: err.message });
  }
};

// POST /api/violations - used by the "SAVE VIOLATION" button after AI detection
exports.createViolation = async (req, res) => {
  try {
    const {
      vehicleNumber, violationType, vehicleType, date, time,
      location, confidence, evidenceImage, fineAmount, isDemo,
    } = req.body;

    if (!vehicleNumber || !violationType || !fineAmount) {
      return res.status(400).json({ success: false, message: "vehicleNumber, violationType and fineAmount are required" });
    }

    const violation = await Violation.create({
      vehicleNumber, violationType, vehicleType, date, time,
      location, confidence, evidenceImage, fineAmount, isDemo,
    });

    res.status(201).json({ success: true, violation });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not save violation", error: err.message });
  }
};

exports.updateViolation = async (req, res) => {
  try {
    const violation = await Violation.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!violation) return res.status(404).json({ success: false, message: "Violation not found" });
    res.json({ success: true, violation });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not update violation", error: err.message });
  }
};

exports.deleteViolation = async (req, res) => {
  try {
    const violation = await Violation.findByIdAndDelete(req.params.id);
    if (!violation) return res.status(404).json({ success: false, message: "Violation not found" });
    res.json({ success: true, message: "Violation deleted" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not delete violation", error: err.message });
  }
};
