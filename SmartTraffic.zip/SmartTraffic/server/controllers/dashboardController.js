const Violation = require("../models/Violation");

exports.getStats = async (req, res) => {
  try {
    const totalViolations = await Violation.countDocuments();
    const uniqueVehicles = await Violation.distinct("vehicleNumber");

    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const todaysViolations = await Violation.countDocuments({ createdAt: { $gte: startOfToday } });

    const byType = await Violation.aggregate([
      { $group: { _id: "$violationType", count: { $sum: 1 } } },
    ]);
    const typeCounts = { "No Helmet": 0, "No Seat Belt": 0, "Red Light": 0, "Over Speeding": 0 };
    byType.forEach((t) => { typeCounts[t._id] = t.count; });

    // Violations over the last 7 days, grouped by day, for the trend chart
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
    sevenDaysAgo.setHours(0, 0, 0, 0);
    const recentByDay = await Violation.aggregate([
      { $match: { createdAt: { $gte: sevenDaysAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    const recentViolations = await Violation.find().sort({ createdAt: -1 }).limit(5);

    res.json({
      success: true,
      stats: {
        totalVehicles: uniqueVehicles.length,
        totalViolations,
        todaysViolations,
        noHelmet: typeCounts["No Helmet"],
        noSeatBelt: typeCounts["No Seat Belt"],
        redLight: typeCounts["Red Light"],
        overSpeeding: typeCounts["Over Speeding"],
      },
      violationsByType: Object.entries(typeCounts).map(([name, value]) => ({ name, value })),
      violationsOverTime: recentByDay.map((d) => ({ date: d._id, count: d.count })),
      recentViolations,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not load dashboard stats", error: err.message });
  }
};
