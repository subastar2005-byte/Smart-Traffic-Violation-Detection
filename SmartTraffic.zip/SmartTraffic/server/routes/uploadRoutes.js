const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const axios = require("axios");
const { protect } = require("../middleware/auth");

const uploadsDir = path.join(__dirname, "..", "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  },
});

const allowed = [".jpg", ".jpeg", ".png", ".mp4", ".avi"];
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowed.includes(ext)) {
      return cb(new Error("Unsupported file type. Please upload JPG, JPEG, PNG, MP4 or AVI."));
    }
    cb(null, true);
  },
});

const AI_SERVICE_URL = process.env.AI_SERVICE_URL || "http://127.0.0.1:8000";

const SAMPLE_PLATES = ["TN72AB1234", "TN72CD5678", "TN74EF9012", "TN75GH3456", "TN69KL7890"];
const VIOLATION_TYPES = [
  { type: "No Helmet", fine: 1000, vehicleType: "Motorcycle" },
  { type: "No Seat Belt", fine: 1000, vehicleType: "Car" },
  { type: "Red Light", fine: 1000, vehicleType: "Car" },
  { type: "Over Speeding", fine: 2000, vehicleType: "Bus" },
];

// Local, clearly-labelled fallback used only if the Python AI service cannot be reached
function buildFallbackResult(filename) {
  const pick = VIOLATION_TYPES[Math.floor(Math.random() * VIOLATION_TYPES.length)];
  const plate = SAMPLE_PLATES[Math.floor(Math.random() * SAMPLE_PLATES.length)];
  const now = new Date();
  return {
    success: true,
    isDemo: true,
    demoReason: "Python AI service was unreachable, showing a simulated result so the workflow can still be demonstrated.",
    vehicleNumber: plate,
    vehicleType: pick.vehicleType,
    violationType: pick.type,
    confidence: Math.floor(75 + Math.random() * 20),
    fineAmount: pick.fine,
    date: now.toLocaleDateString("en-GB"),
    time: now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
    location: "Tirunelveli",
    evidenceImage: `/uploads/${filename}`,
  };
}

router.post("/", protect, (req, res) => {
  upload.single("file")(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ success: false, message: err.message });
    }
    if (!req.file) {
      return res.status(400).json({ success: false, message: "No file was uploaded" });
    }

    const filePath = req.file.path;
    const filename = req.file.filename;

    try {
      // Forward the saved file to the Python AI microservice for detection
      const form = new (require("form-data"))();
      form.append("file", fs.createReadStream(filePath), filename);

      const aiResponse = await axios.post(`${AI_SERVICE_URL}/detect`, form, {
        headers: form.getHeaders(),
        timeout: 30000,
      });

      const result = aiResponse.data;
      return res.json({
        success: true,
        isDemo: !!result.isDemo,
        demoReason: result.demoReason || null,
        vehicleNumber: result.vehicleNumber || "UNKNOWN",
        vehicleType: result.vehicleType || "Unknown",
        violationType: result.violationType || "No Helmet",
        confidence: result.confidence ?? 0,
        fineAmount: result.fineAmount ?? 1000,
        date: result.date || new Date().toLocaleDateString("en-GB"),
        time: result.time || new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
        location: result.location || "Tirunelveli",
        evidenceImage: `/uploads/${filename}`,
      });
    } catch (aiErr) {
      console.error("AI service call failed, using fallback:", aiErr.message);
      // The AI service being down must never crash the app - fall back to a clearly labelled demo result
      return res.json(buildFallbackResult(filename));
    }
  });
});

module.exports = router;
