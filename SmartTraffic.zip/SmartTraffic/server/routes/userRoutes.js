const express = require("express");
const router = express.Router();
const { protect, requireRole } = require("../middleware/auth");
const { getUsers, deleteUser } = require("../controllers/userController");

router.get("/", protect, requireRole("Admin"), getUsers);
router.delete("/:id", protect, requireRole("Admin"), deleteUser);

module.exports = router;
