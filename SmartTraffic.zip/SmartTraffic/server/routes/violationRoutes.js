const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  getViolations, getViolationById, createViolation, updateViolation, deleteViolation,
} = require("../controllers/violationController");

router.use(protect); // every violation route requires login

router.get("/", getViolations);
router.get("/:id", getViolationById);
router.post("/", createViolation);
router.put("/:id", updateViolation);
router.delete("/:id", deleteViolation);

module.exports = router;
