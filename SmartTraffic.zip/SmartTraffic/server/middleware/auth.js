const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "smarttraffic_super_secret_change_me";

// Verifies the Bearer token and attaches the decoded user to req.user
function protect(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ success: false, message: "Not authorized, no token provided" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: "Not authorized, invalid or expired token" });
  }
}

// Restricts a route to one or more roles, e.g. requireRole("Admin")
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: "Forbidden: insufficient permissions" });
    }
    next();
  };
}

module.exports = { protect, requireRole, JWT_SECRET };
