const mongoose = require("mongoose");

const violationSchema = new mongoose.Schema(
  {
    vehicleNumber: { type: String, required: true, trim: true, uppercase: true },
    violationType: {
      type: String,
      required: true,
      enum: ["No Helmet", "No Seat Belt", "Red Light", "Over Speeding"],
    },
    vehicleType: { type: String, default: "Unknown" },
    date: { type: String, required: true }, // dd/mm/yyyy, stored as string for easy display
    time: { type: String, required: true }, // hh:mm AM/PM
    location: { type: String, default: "Tirunelveli" },
    confidence: { type: Number, default: 0 }, // 0-100
    evidenceImage: { type: String, default: "" }, // relative path served from /uploads
    fineAmount: { type: Number, required: true },
    status: { type: String, enum: ["Pending", "Paid", "Disputed"], default: "Pending" },
    isDemo: { type: Boolean, default: false }, // true for seeded/simulated sample records
  },
  { timestamps: true }
);

module.exports = mongoose.model("Violation", violationSchema);
