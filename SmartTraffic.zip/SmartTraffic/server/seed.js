// seed.js - populates MongoDB with demo users and sample violations
// Run with: npm run seed   (make sure MongoDB is running and .env is configured first)
require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");
const Violation = require("./models/Violation");

const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/smart_traffic";

const sampleViolations = [
  { vehicleNumber: "TN72AB1234", violationType: "No Helmet", vehicleType: "Motorcycle", fineAmount: 1000, confidence: 92 },
  { vehicleNumber: "TN72CD5678", violationType: "Red Light", vehicleType: "Car", fineAmount: 1000, confidence: 88 },
  { vehicleNumber: "TN74EF9012", violationType: "Over Speeding", vehicleType: "Bus", fineAmount: 2000, confidence: 95 },
  { vehicleNumber: "TN75GH3456", violationType: "No Seat Belt", vehicleType: "Car", fineAmount: 1000, confidence: 81 },
  { vehicleNumber: "TN72AB1234", violationType: "Over Speeding", vehicleType: "Motorcycle", fineAmount: 2000, confidence: 90 },
  { vehicleNumber: "TN69KL7890", violationType: "No Helmet", vehicleType: "Motorcycle", fineAmount: 1000, confidence: 87 },
  { vehicleNumber: "TN72CD5678", violationType: "No Seat Belt", vehicleType: "Car", fineAmount: 1000, confidence: 79 },
  { vehicleNumber: "TN74EF9012", violationType: "Red Light", vehicleType: "Bus", fineAmount: 1000, confidence: 93 },
];

async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log("Connected to MongoDB for seeding");

  const existingAdmin = await User.findOne({ email: "admin@smarttraffic.com" });
  if (!existingAdmin) {
    const hashedAdmin = await bcrypt.hash("Admin@123", 10);
    await User.create({ name: "System Admin", email: "admin@smarttraffic.com", password: hashedAdmin, role: "Admin" });
    console.log("Created demo Admin user: admin@smarttraffic.com / Admin@123");
  } else {
    console.log("Demo Admin user already exists, skipping");
  }

  const existingPolice = await User.findOne({ email: "police@smarttraffic.com" });
  if (!existingPolice) {
    const hashedPolice = await bcrypt.hash("Police@123", 10);
    await User.create({ name: "Traffic Officer", email: "police@smarttraffic.com", password: hashedPolice, role: "Traffic Police" });
    console.log("Created demo Traffic Police user: police@smarttraffic.com / Police@123");
  } else {
    console.log("Demo Traffic Police user already exists, skipping");
  }

  const count = await Violation.countDocuments();
  if (count === 0) {
    const now = new Date();
    const docs = sampleViolations.map((v, i) => {
      const d = new Date(now);
      d.setDate(d.getDate() - (i % 5)); // spread across the last few days for the trend chart
      return {
        ...v,
        location: "Tirunelveli",
        date: d.toLocaleDateString("en-GB"),
        time: d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
        status: i % 3 === 0 ? "Paid" : "Pending",
        evidenceImage: "",
        isDemo: true,
        createdAt: d,
      };
    });
    await Violation.insertMany(docs);
    console.log(`Inserted ${docs.length} sample violation records (marked isDemo: true)`);
  } else {
    console.log("Violations already exist, skipping sample data insert");
  }

  console.log("Seeding complete");
  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error("Seeding failed:", err.message);
  process.exit(1);
});
