import axios from "axios";

// Change this if your backend runs on a different port
export const API_BASE_URL = "http://localhost:5000/api";
export const FILE_BASE_URL = "http://localhost:5000";

const api = axios.create({ baseURL: API_BASE_URL });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("st_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    // Normalize network/backend-down errors so pages can show a friendly message
    if (!err.response) {
      err.friendlyMessage = "Could not reach the backend server. Make sure it is running on port 5000.";
    } else {
      err.friendlyMessage = err.response.data?.message || "Something went wrong. Please try again.";
    }
    return Promise.reject(err);
  }
);

export default api;
