import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

const links = [
  { to: "/dashboard", label: "Dashboard", icon: "grid" },
  { to: "/upload", label: "Upload Footage", icon: "upload" },
  { to: "/violations", label: "Violations", icon: "alert" },
  { to: "/vehicles", label: "Vehicles", icon: "car" },
  { to: "/reports", label: "Reports", icon: "file" },
  { to: "/profile", label: "Profile", icon: "user" },
];

const icons = {
  grid: <path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z" />,
  upload: <path d="M12 3v12m0-12 4 4m-4-4-4 4M5 17v2a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2" />,
  alert: <path d="M12 3 2 20h20L12 3Zm0 6v5m0 3h.01" />,
  car: <path d="M4 17h16M5 17V11l2-5h10l2 5v6M7 17a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm14 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z" />,
  file: <path d="M6 3h9l5 5v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm9 0v5h5" />,
  user: <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 8a7 7 0 0 1 14 0" />,
  users: <path d="M17 20v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1m17 0v-1a4 4 0 0 0-3-3.87M14 4.13a4 4 0 0 1 0 7.75M13 8a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z" />,
  logout: <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4m7 14 5-5-5-5m5 5H9" />,
};

function Icon({ name }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      {icons[name]}
    </svg>
  );
}

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const items = [...links];
  if (user?.role === "Admin") {
    items.splice(5, 0, { to: "/users", label: "Users", icon: "users" });
  }

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <aside className="st-sidebar">
      <div className="st-sidebar-brand">
        <span className="st-brand-mark">ST</span>
        <div>
          <div className="st-brand-title">Smart Traffic</div>
          <div className="st-brand-sub">Violation Detection</div>
        </div>
      </div>

      <nav className="st-sidebar-nav">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => "st-sidebar-link" + (isActive ? " active" : "")}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="st-sidebar-footer">
        <div className="st-sidebar-user">
          <div className="st-avatar">{user?.name?.charAt(0) || "U"}</div>
          <div>
            <div className="st-sidebar-user-name">{user?.name}</div>
            <div className="st-sidebar-user-role">{user?.role}</div>
          </div>
        </div>
        <button className="st-sidebar-link st-logout-btn" onClick={handleLogout}>
          <Icon name="logout" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
