import React from "react";
import Sidebar from "./Sidebar.jsx";
import Navbar from "./Navbar.jsx";

export default function Layout({ title, children }) {
  return (
    <div className="st-app-shell">
      <Sidebar />
      <div className="st-main">
        <Navbar title={title} />
        <main className="st-content">{children}</main>
      </div>
    </div>
  );
}
