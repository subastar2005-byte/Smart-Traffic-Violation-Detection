import React from "react";
import { useAuth } from "../context/AuthContext.jsx";

export default function Navbar({ title }) {
  const { user } = useAuth();
  const today = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });

  return (
    <header className="st-navbar">
      <h1 className="st-navbar-title">{title}</h1>
      <div className="st-navbar-right">
        <span className="st-navbar-date">{today}</span>
        <span className="st-badge st-badge-role">{user?.role}</span>
      </div>
    </header>
  );
}
