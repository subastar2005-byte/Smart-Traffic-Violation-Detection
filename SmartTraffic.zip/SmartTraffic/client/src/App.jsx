import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import UploadFootage from "./pages/UploadFootage.jsx";
import DetectionResults from "./pages/DetectionResults.jsx";
import Violations from "./pages/Violations.jsx";
import ViolationDetails from "./pages/ViolationDetails.jsx";
import Vehicles from "./pages/Vehicles.jsx";
import Reports from "./pages/Reports.jsx";
import Profile from "./pages/Profile.jsx";
import Users from "./pages/Users.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Navigate to="/login" replace />} />

      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/upload" element={<ProtectedRoute><UploadFootage /></ProtectedRoute>} />
      <Route path="/detection-results" element={<ProtectedRoute><DetectionResults /></ProtectedRoute>} />
      <Route path="/violations" element={<ProtectedRoute><Violations /></ProtectedRoute>} />
      <Route path="/violations/:id" element={<ProtectedRoute><ViolationDetails /></ProtectedRoute>} />
      <Route path="/vehicles" element={<ProtectedRoute><Vehicles /></ProtectedRoute>} />
      <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
      <Route path="/users" element={<ProtectedRoute adminOnly><Users /></ProtectedRoute>} />

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
