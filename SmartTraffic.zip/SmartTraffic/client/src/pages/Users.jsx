import React, { useEffect, useState } from "react";
import Layout from "../components/Layout.jsx";
import api from "../services/api.js";
import { useAuth } from "../context/AuthContext.jsx";

export default function Users() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const { user: currentUser } = useAuth();

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/users");
      setUsers(res.data.users);
    } catch (err) {
      setError(err.friendlyMessage || "Could not load users.");
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this user account?")) return;
    try {
      await api.delete(`/users/${id}`);
      setUsers((prev) => prev.filter((u) => u._id !== id));
    } catch (err) {
      setError(err.friendlyMessage || "Could not delete user.");
    }
  }

  return (
    <Layout title="Users">
      {error && <div className="st-alert st-alert-error">{error}</div>}
      <div className="st-card">
        <table className="st-table">
          <thead>
            <tr><th>Name</th><th>Email</th><th>Role</th><th>Created</th><th>Action</th></tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} style={{ color: "var(--st-text-muted)" }}>Loading...</td></tr>}
            {!loading && users.length === 0 && (
              <tr><td colSpan={5} style={{ color: "var(--st-text-muted)" }}>No users found.</td></tr>
            )}
            {users.map((u) => (
              <tr key={u._id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td><span className="st-badge st-badge-role">{u.role}</span></td>
                <td>{new Date(u.createdAt).toLocaleDateString("en-GB")}</td>
                <td>
                  <button
                    className="st-btn st-btn-danger st-btn-sm"
                    onClick={() => handleDelete(u._id)}
                    disabled={u._id === currentUser?.id}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}
