import React, { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout.jsx";
import api from "../services/api.js";

const STAGES = [
  "File Uploaded Successfully",
  "Processing CCTV Footage...",
  "AI Detection in Progress...",
];

export default function UploadFootage() {
  const [file, setFile] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [stage, setStage] = useState(-1);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const inputRef = useRef(null);
  const navigate = useNavigate();

  function pickFile(f) {
    if (!f) return;
    const allowed = ["image/jpeg", "image/jpg", "image/png", "video/mp4", "video/avi", "video/x-msvideo"];
    const okExt = /\.(jpg|jpeg|png|mp4|avi)$/i.test(f.name);
    if (!allowed.includes(f.type) && !okExt) {
      setError("Unsupported file type. Please choose a JPG, JPEG, PNG, MP4 or AVI file.");
      return;
    }
    setError("");
    setFile(f);
  }

  async function handleUpload() {
    if (!file) {
      setError("Please choose a file first.");
      return;
    }
    setBusy(true);
    setError("");
    setStage(0);

    try {
      const formData = new FormData();
      formData.append("file", file);

      // Advance stage labels while the request is in flight for a realistic feel
      const t1 = setTimeout(() => setStage(1), 600);
      const t2 = setTimeout(() => setStage(2), 1400);

      const res = await api.post("/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      clearTimeout(t1);
      clearTimeout(t2);

      navigate("/detection-results", { state: { result: res.data } });
    } catch (err) {
      setError(err.friendlyMessage || "Upload failed. Please try again.");
      setStage(-1);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Layout title="Upload CCTV Footage">
      <div className="st-card" style={{ maxWidth: 640, margin: "0 auto" }}>
        <h2 style={{ fontSize: 16, marginBottom: 4 }}>Upload Image or Video</h2>
        <p style={{ color: "var(--st-text-muted)", fontSize: 13.5, marginBottom: 18 }}>
          Supported formats: JPG, JPEG, PNG, MP4, AVI
        </p>

        {error && <div className="st-alert st-alert-error">{error}</div>}

        <div
          className={"st-upload-dropzone" + (dragging ? " dragging" : "")}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); pickFile(e.dataTransfer.files[0]); }}
          onClick={() => inputRef.current?.click()}
          style={{ cursor: "pointer" }}
        >
          <input
            ref={inputRef}
            type="file"
            accept=".jpg,.jpeg,.png,.mp4,.avi"
            style={{ display: "none" }}
            onChange={(e) => pickFile(e.target.files[0])}
          />
          {file ? (
            <div>
              <strong>{file.name}</strong>
              <div style={{ fontSize: 12.5, color: "var(--st-text-muted)", marginTop: 4 }}>
                {(file.size / 1024 / 1024).toFixed(2)} MB — click to choose a different file
              </div>
            </div>
          ) : (
            <div>
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Choose File</div>
              <div style={{ fontSize: 12.5, color: "var(--st-text-muted)" }}>or drag and drop it here</div>
            </div>
          )}
        </div>

        <button
          className="st-btn st-btn-primary"
          style={{ width: "100%", marginTop: 18 }}
          onClick={handleUpload}
          disabled={busy}
        >
          {busy ? "Processing..." : "UPLOAD & DETECT"}
        </button>

        {stage >= 0 && (
          <div style={{ marginTop: 20 }}>
            <div className="st-progress-track">
              <div className="st-progress-fill" style={{ width: `${((stage + 1) / STAGES.length) * 100}%` }} />
            </div>
            <p style={{ fontSize: 13, marginTop: 10, color: "var(--st-text-muted)" }}>{STAGES[stage]}</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
