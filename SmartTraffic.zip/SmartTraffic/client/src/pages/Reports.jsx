import React, { useEffect, useState } from "react";
import Layout from "../components/Layout.jsx";
import api from "../services/api.js";

export default function Reports() {
  const [violations, setViolations] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const res = await api.get("/violations", { params: { limit: 500, page: 1 } });
      setViolations(res.data.violations);
    } catch (err) {
      setError(err.friendlyMessage || "Could not load report data.");
    }
  }

  function handlePrint() {
    window.print();
  }

  function handleDownload() {
    const header = ["Vehicle Number", "Violation Type", "Date", "Time", "Location", "Fine", "Status"];
    const rows = violations.map((v) => [v.vehicleNumber, v.violationType, v.date, v.time, v.location, v.fineAmount, v.status]);
    const csv = [header, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "traffic_violation_report.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Layout title="Reports">
      {error && <div className="st-alert st-alert-error">{error}</div>}

      <div className="d-flex justify-content-between align-items-center mb-3 st-no-print">
        <h2 style={{ fontSize: 16, margin: 0 }}>Traffic Violation Report</h2>
        <div className="d-flex gap-2">
          <button className="st-btn st-btn-outline" onClick={handlePrint}>PRINT REPORT</button>
          <button className="st-btn st-btn-primary" onClick={handleDownload}>DOWNLOAD REPORT</button>
        </div>
      </div>

      <div className="st-card" id="st-report-print-area">
        <h2 style={{ fontSize: 16, marginBottom: 4 }}>Traffic Violation Report</h2>
        <p style={{ fontSize: 12.5, color: "var(--st-text-muted)", marginBottom: 16 }}>
          Generated {new Date().toLocaleString("en-GB")}
        </p>
        <table className="st-table">
          <thead>
            <tr><th>Vehicle Number</th><th>Violation Type</th><th>Date</th><th>Time</th><th>Location</th><th>Fine</th><th>Status</th></tr>
          </thead>
          <tbody>
            {violations.map((v) => (
              <tr key={v._id}>
                <td className="st-mono">{v.vehicleNumber}</td>
                <td>{v.violationType}</td>
                <td>{v.date}</td>
                <td>{v.time}</td>
                <td>{v.location}</td>
                <td>₹{v.fineAmount}</td>
                <td>{v.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <style>{`
        @media print {
          .st-sidebar, .st-navbar, .st-no-print { display: none !important; }
          .st-content { padding: 0 !important; }
        }
      `}</style>
    </Layout>
  );
}
