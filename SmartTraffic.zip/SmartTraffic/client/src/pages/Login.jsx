import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api.js";
import { useAuth } from "../context/AuthContext.jsx";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("Admin");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!email || !password) {
      setError("Please enter both email and password.");
      return;
    }
    setLoading(true);
    try {
      const res = await api.post("/auth/login", { email, password, role });
      login(res.data.token, res.data.user);
      navigate("/dashboard");
    } catch (err) {
      setError(err.friendlyMessage || "Login failed. Please check your credentials.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="st-login-wrap">
      <div className="st-login-card">
        <div className="st-login-mark">ST</div>
        <h1 className="st-login-title">Smart Traffic<br />Violation Detection System</h1>
        <p className="st-login-sub">Sign in to access the traffic monitoring console.</p>

        {error && <div className="st-alert st-alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label className="st-label">Email</label>
            <input
              className="st-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@smarttraffic.com"
              autoComplete="username"
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label className="st-label">Password</label>
            <input
              className="st-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </div>

          <div style={{ marginBottom: 22 }}>
            <label className="st-label">Role</label>
            <select className="st-select" value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="Admin">Admin</option>
              <option value="Traffic Police">Traffic Police</option>
            </select>
          </div>

          <button className="st-btn st-btn-primary" type="submit" style={{ width: "100%" }} disabled={loading}>
            {loading ? "Signing in..." : "LOGIN"}
          </button>
        </form>

        <div className="st-demo-box">
          <strong>Demo credentials</strong><br />
          Admin — admin@smarttraffic.com / Admin@123<br />
          Traffic Police — police@smarttraffic.com / Police@123<br />
          (Run <span className="st-mono">npm run seed</span> in <span className="st-mono">server/</span> to create these accounts.)
        </div>
      </div>
    </div>
  );
}
