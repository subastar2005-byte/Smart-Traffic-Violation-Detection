import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "../components/Layout.jsx";
import api from "../services/api.js";

const VIOLATION_TYPES = ["All", "No Helmet", "No Seat Belt", "Red Light", "Over Speeding"];
const STATUSES = ["All", "Pending", "Paid", "Disputed"];

export default function Violations() {
  const [violations, setViolations] = useState([]);
  const [search, setSearch] = useState("");
  const [violationType, setViolationType] = useState("All");
  const [status, setStatus] = useState("All");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, violationType, status]);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/violations", {
        params: { vehicleNumber: search, violationType, status, page, limit: 8 },
      });
      setViolations(res.data.violations);
      setPages(res.data.pages);
    } catch (err) {
      setError(err.friendlyMessage || "Could not load violations.");
    } finally {
      setLoading(false);
    }
  }

  function handleSearch(e) {
    e.preventDefault();
    setPage(1);
    load();
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this violation record? This cannot be undone.")) return;
    try {
      await api.delete(`/violations/${id}`);
      setViolations((prev) => prev.filter((v) => v._id !== id));
    } catch (err) {
      setError(err.friendlyMessage || "Could not delete violation.");
    }
  }

  return (
    <Layout title="Violations">
      {error && <div className="st-alert st-alert-error">{error}</div>}

      <form className="st-card mb-3" onSubmit={handleSearch}>
        <div className="row g-2 align-items-end">
          <div className="col-md-4">
            <label className="st-label">Search Vehicle Number</label>
            <input className="st-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="e.g. TN72AB1234" />
          </div>
          <div className="col-md-3">
            <label className="st-label">Filter Violation</label>
            <select className="st-select" value={violationType} onChange={(e) => { setViolationType(e.target.value); setPage(1); }}>
              {VIOLATION_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="col-md-3">
            <label className="st-label">Filter Status</label>
            <select className="st-select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="col-md-2">
            <button className="st-btn st-btn-primary" style={{ width: "100%" }} type="submit">Search</button>
          </div>
        </div>
      </form>

      <div className="st-card">
        <table className="st-table">
          <thead>
            <tr>
              <th>ID</th><th>Vehicle</th><th>Violation</th><th>Date</th><th>Location</th><th>Fine</th><th>Status</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={8} style={{ color: "var(--st-text-muted)" }}>Loading...</td></tr>}
            {!loading && violations.length === 0 && (
              <tr><td colSpan={8} style={{ color: "var(--st-text-muted)" }}>No violations found.</td></tr>
            )}
            {violations.map((v) => (
              <tr key={v._id}>
                <td className="st-mono">{v._id.slice(-6).toUpperCase()}</td>
                <td className="st-mono">{v.vehicleNumber}</td>
                <td>
                  {v.violationType}
                  {v.isDemo && <span className="st-badge st-badge-demo ms-2">DEMO</span>}
                </td>
                <td>{v.date}</td>
                <td>{v.location}</td>
                <td>₹{v.fineAmount}</td>
                <td><span className={`st-badge st-badge-${v.status.toLowerCase()}`}>{v.status}</span></td>
                <td>
                  <Link to={`/violations/${v._id}`} className="st-btn st-btn-outline st-btn-sm me-2">View</Link>
                  <button className="st-btn st-btn-danger st-btn-sm" onClick={() => handleDelete(v._id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="d-flex justify-content-between align-items-center mt-3">
          <span style={{ fontSize: 13, color: "var(--st-text-muted)" }}>Page {page} of {pages}</span>
          <div className="d-flex gap-2">
            <button className="st-btn st-btn-outline st-btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
            <button className="st-btn st-btn-outline st-btn-sm" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>Next</button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
