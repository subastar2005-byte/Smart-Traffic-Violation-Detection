import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, CartesianGrid,
} from "recharts";
import Layout from "../components/Layout.jsx";
import api from "../services/api.js";

const COLORS = ["#E4483C", "#F5A623", "#1E9E6B", "#3B82F6"];

const statCards = [
  { key: "totalVehicles", label: "Total Vehicles", color: "#3B82F6" },
  { key: "totalViolations", label: "Total Violations", color: "#E4483C" },
  { key: "todaysViolations", label: "Today's Violations", color: "#F5A623" },
  { key: "noHelmet", label: "Helmet Violations", color: "#E4483C" },
  { key: "noSeatBelt", label: "Seat Belt Violations", color: "#F5A623" },
  { key: "redLight", label: "Red Light Violations", color: "#DC2626" },
  { key: "overSpeeding", label: "Over Speeding", color: "#1E9E6B" },
];

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [byType, setByType] = useState([]);
  const [overTime, setOverTime] = useState([]);
  const [recent, setRecent] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/dashboard/stats");
      setStats(res.data.stats);
      setByType(res.data.violationsByType);
      setOverTime(res.data.violationsOverTime);
      setRecent(res.data.recentViolations);
    } catch (err) {
      setError(err.friendlyMessage || "Could not load dashboard data.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout title="Smart Traffic Dashboard">
      {error && <div className="st-alert st-alert-error">{error}</div>}
      {loading && <p style={{ color: "var(--st-text-muted)" }}>Loading dashboard...</p>}

      {stats && (
        <>
          <div className="row g-3 mb-3">
            {statCards.map((c) => (
              <div className="col-6 col-md-4 col-lg-3" key={c.key}>
                <div className="st-card st-stat-card">
                  <span className="st-stat-label">{c.label}</span>
                  <span className="st-stat-value">{stats[c.key]}</span>
                  <span className="st-stat-accent" style={{ background: c.color }}></span>
                </div>
              </div>
            ))}
          </div>

          <div className="row g-3 mb-3">
            <div className="col-lg-5">
              <div className="st-card" style={{ height: 300 }}>
                <h3 style={{ fontSize: 15, marginBottom: 12 }}>Violations by Type</h3>
                <ResponsiveContainer width="100%" height="85%">
                  <PieChart>
                    <Pie data={byType} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                      {byType.map((entry, i) => <Cell key={entry.name} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="col-lg-7">
              <div className="st-card" style={{ height: 300 }}>
                <h3 style={{ fontSize: 15, marginBottom: 12 }}>Violations Over Time (last 7 days)</h3>
                <ResponsiveContainer width="100%" height="85%">
                  <LineChart data={overTime}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EEF1F5" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Line type="monotone" dataKey="count" stroke="#E4483C" strokeWidth={2.5} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="st-card">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h3 style={{ fontSize: 15, margin: 0 }}>Recent Violations</h3>
              <Link to="/violations" className="st-btn st-btn-outline st-btn-sm">View all</Link>
            </div>
            <table className="st-table">
              <thead>
                <tr><th>Vehicle</th><th>Violation</th><th>Location</th><th>Fine</th><th>Status</th></tr>
              </thead>
              <tbody>
                {recent.length === 0 && (
                  <tr><td colSpan={5} style={{ color: "var(--st-text-muted)" }}>No violations recorded yet.</td></tr>
                )}
                {recent.map((v) => (
                  <tr key={v._id}>
                    <td className="st-mono">{v.vehicleNumber}</td>
                    <td>{v.violationType}</td>
                    <td>{v.location}</td>
                    <td>₹{v.fineAmount}</td>
                    <td><span className={`st-badge st-badge-${v.status.toLowerCase()}`}>{v.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </Layout>
  );
}
