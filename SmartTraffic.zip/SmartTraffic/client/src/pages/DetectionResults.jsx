import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Layout from "../components/Layout.jsx";
import api from "../services/api.js";
import { FILE_BASE_URL } from "../services/api.js";

export default function DetectionResults() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const result = state?.result;

  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  if (!result) {
    return (
      <Layout title="AI Detection Result">
        <div className="st-card">
          <p>No detection result to show yet.</p>
          <button className="st-btn st-btn-primary" onClick={() => navigate("/upload")}>Upload footage</button>
        </div>
      </Layout>
    );
  }

  async function handleSave() {
    setSaving(true);
    setError("");
    try {
      await api.post("/violations", {
        vehicleNumber: result.vehicleNumber,
        violationType: result.violationType,
        vehicleType: result.vehicleType,
        date: result.date,
        time: result.time,
        location: result.location,
        confidence: result.confidence,
        evidenceImage: result.evidenceImage,
        fineAmount: result.fineAmount,
        isDemo: result.isDemo,
      });
      setSaved(true);
    } catch (err) {
      setError(err.friendlyMessage || "Could not save violation.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Layout title="AI Detection Result">
      <div className="row g-3">
        <div className="col-lg-6">
          <div className="st-card">
            <h3 style={{ fontSize: 14, marginBottom: 10 }}>Evidence Image</h3>
            {result.evidenceImage ? (
              <img
                className="st-evidence-frame"
                src={`${FILE_BASE_URL}${result.evidenceImage}`}
                alt="Evidence"
                onError={(e) => { e.target.style.display = "none"; }}
              />
            ) : (
              <div className="st-evidence-frame d-flex align-items-center justify-content-center" style={{ color: "#8A93A0" }}>
                No preview available
              </div>
            )}
          </div>
        </div>

        <div className="col-lg-6">
          <div className="st-card">
            {result.isDemo && (
              <div className="st-alert st-alert-info">
                Simulated result: {result.demoReason || "shown because a trained violation-detection model was not available."}
              </div>
            )}
            {error && <div className="st-alert st-alert-error">{error}</div>}
            {saved && <div className="st-alert st-alert-success">Violation saved to the database.</div>}

            <h3 style={{ fontSize: 14, marginBottom: 14 }}>Vehicle Information</h3>

            <dl className="st-detail-list">
              <Row label="Vehicle Number" value={<span className="st-mono">{result.vehicleNumber}</span>} />
              <Row label="Vehicle Type" value={result.vehicleType} />
              <Row label="Violation" value={result.violationType} />
              <Row label="Confidence" value={`${result.confidence}%`} />
              <Row label="Location" value={result.location} />
              <Row label="Date" value={result.date} />
              <Row label="Time" value={result.time} />
              <Row label="Fine" value={`₹${result.fineAmount}`} />
              <Row label="Status" value={<span className="st-badge st-badge-pending">Pending</span>} />
            </dl>

            <button
              className="st-btn st-btn-primary"
              style={{ width: "100%", marginTop: 10 }}
              onClick={handleSave}
              disabled={saving || saved}
            >
              {saved ? "SAVED" : saving ? "SAVING..." : "SAVE VIOLATION"}
            </button>

            {saved && (
              <button className="st-btn st-btn-outline" style={{ width: "100%", marginTop: 10 }} onClick={() => navigate("/violations")}>
                Go to Violations
              </button>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

function Row({ label, value }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderBottom: "1px solid var(--st-border)" }}>
      <span style={{ color: "var(--st-text-muted)", fontSize: 13.5 }}>{label}</span>
      <span style={{ fontWeight: 600, fontSize: 13.5 }}>{value}</span>
    </div>
  );
}
