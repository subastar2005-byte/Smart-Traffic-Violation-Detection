import React, { useEffect, useState } from "react";
import Layout from "../components/Layout.jsx";
import api from "../services/api.js";

export default function Vehicles() {
  const [vehicles, setVehicles] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    setError("");
    try {
      // Pull a large page of violations and aggregate by vehicle on the client,
      // since this is a lightweight college project without a dedicated Vehicle collection.
      const res = await api.get("/violations", { params: { limit: 500, page: 1 } });
      const map = {};
      res.data.violations.forEach((v) => {
        if (!map[v.vehicleNumber]) {
          map[v.vehicleNumber] = { vehicleNumber: v.vehicleNumber, vehicleType: v.vehicleType, count: 0, lastDate: v.date };
        }
        map[v.vehicleNumber].count += 1;
      });
      setVehicles(Object.values(map).sort((a, b) => b.count - a.count));
    } catch (err) {
      setError(err.friendlyMessage || "Could not load vehicles.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout title="Vehicles">
      {error && <div className="st-alert st-alert-error">{error}</div>}
      <div className="st-card">
        <table className="st-table">
          <thead>
            <tr><th>Vehicle Number</th><th>Vehicle Type</th><th>Total Violations</th><th>Last Violation</th><th>Status</th></tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} style={{ color: "var(--st-text-muted)" }}>Loading...</td></tr>}
            {!loading && vehicles.length === 0 && (
              <tr><td colSpan={5} style={{ color: "var(--st-text-muted)" }}>No vehicles recorded yet.</td></tr>
            )}
            {vehicles.map((v) => (
              <tr key={v.vehicleNumber}>
                <td className="st-mono">{v.vehicleNumber}</td>
                <td>{v.vehicleType}</td>
                <td>{v.count} violation{v.count > 1 ? "s" : ""}</td>
                <td>{v.lastDate}</td>
                <td>
                  {v.count >= 3
                    ? <span className="st-badge st-badge-disputed">Flagged</span>
                    : <span className="st-badge st-badge-paid">Normal</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}
