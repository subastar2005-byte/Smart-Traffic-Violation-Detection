import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Layout from "../components/Layout.jsx";
import api, { FILE_BASE_URL } from "../services/api.js";

export default function ViolationDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [violation, setViolation] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function load() {
    setError("");
    try {
      const res = await api.get(`/violations/${id}`);
      setViolation(res.data.violation);
    } catch (err) {
      setError(err.friendlyMessage || "Could not load violation details.");
    }
  }

  return (
    <Layout title="Violation Details">
      {error && <div className="st-alert st-alert-error">{error}</div>}
      {!violation && !error && <p style={{ color: "var(--st-text-muted)" }}>Loading...</p>}

      {violation && (
        <div className="row g-3">
          <div className="col-lg-7">
            <div className="st-card">
              <h3 style={{ fontSize: 15, marginBottom: 16 }}>
                Violation ID: <span className="st-mono">VIO-{violation._id.slice(-6).toUpperCase()}</span>
              </h3>
              <Row label="Vehicle Number" value={<span className="st-mono">{violation.vehicleNumber}</span>} />
              <Row label="Vehicle Type" value={violation.vehicleType} />
              <Row label="Violation" value={violation.violationType} />
              <Row label="Date" value={violation.date} />
              <Row label="Time" value={violation.time} />
              <Row label="Location" value={violation.location} />
              <Row label="Confidence" value={`${violation.confidence}%`} />
              <Row label="Fine" value={`₹${violation.fineAmount}`} />
              <Row label="Status" value={<span className={`st-badge st-badge-${violation.status.toLowerCase()}`}>{violation.status}</span>} />
              {violation.isDemo && <Row label="Record Type" value={<span className="st-badge st-badge-demo">DEMO / SAMPLE</span>} />}

              <button className="st-btn st-btn-outline" style={{ marginTop: 16 }} onClick={() => navigate("/violations")}>Back to Violations</button>
            </div>
          </div>

          <div className="col-lg-5">
            <div className="st-card">
              <h3 style={{ fontSize: 14, marginBottom: 10 }}>Evidence Image</h3>
              {violation.evidenceImage ? (
                <img
                  className="st-evidence-frame"
                  src={`${FILE_BASE_URL}${violation.evidenceImage}`}
                  alt="Evidence"
                  onError={(e) => { e.target.style.display = "none"; }}
                />
              ) : (
                <div className="st-evidence-frame d-flex align-items-center justify-content-center" style={{ color: "#8A93A0" }}>
                  No evidence image for this record
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}

function Row({ label, value }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderBottom: "1px solid var(--st-border)" }}>
      <span style={{ color: "var(--st-text-muted)", fontSize: 13.5 }}>{label}</span>
      <span style={{ fontWeight: 600, fontSize: 13.5 }}>{value}</span>
    </div>
  );
}
