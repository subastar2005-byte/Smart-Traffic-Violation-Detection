import React, { useState } from "react";
import Layout from "../components/Layout.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function Profile() {
  const { user, login } = useAuth();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name || "");

  function handleSave() {
    // College-project scope: name is updated locally only (no PUT /api/users/:id
    // endpoint was requested). Wire this to a real API call for production use.
    const token = localStorage.getItem("st_token");
    login(token, { ...user, name });
    setEditing(false);
  }

  return (
    <Layout title="Profile">
      <div className="st-card" style={{ maxWidth: 420 }}>
        <div className="d-flex align-items-center gap-3 mb-4">
          <div className="st-avatar" style={{ width: 56, height: 56, fontSize: 22 }}>
            {user?.name?.charAt(0)}
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>{user?.name}</div>
            <span className="st-badge st-badge-role">{user?.role}</span>
          </div>
        </div>

        <div style={{ marginBottom: 14 }}>
          <label className="st-label">Name</label>
          {editing ? (
            <input className="st-input" value={name} onChange={(e) => setName(e.target.value)} />
          ) : (
            <div>{user?.name}</div>
          )}
        </div>

        <div style={{ marginBottom: 14 }}>
          <label className="st-label">Email</label>
          <div>{user?.email}</div>
        </div>

        <div style={{ marginBottom: 18 }}>
          <label className="st-label">Role</label>
          <div>{user?.role}</div>
        </div>

        {editing ? (
          <button className="st-btn st-btn-primary" onClick={handleSave}>Save Changes</button>
        ) : (
          <button className="st-btn st-btn-outline" onClick={() => setEditing(true)}>Edit Profile</button>
        )}
      </div>
    </Layout>
  );
}
