# Smart Traffic Violation Detection System

A full-stack college project: a MERN web app (React + Node/Express + MongoDB) paired
with a Python AI microservice (OpenCV / YOLO / EasyOCR) that detects vehicles, reads
number plates, and flags traffic violations from uploaded CCTV images or video.

## Abstract

Manual traffic-violation monitoring is slow and inconsistent. This project prototypes
an AI-assisted pipeline: a traffic officer uploads CCTV footage, a computer-vision
service attempts to detect the vehicle and its number plate, a violation type is
identified, and the result is stored and reported through a web dashboard.

## Problem statement

Traffic police cannot manually review every CCTV feed for helmet, seat belt, red-light
and speeding violations. A digital system that can process footage and centralize
violation records reduces manual effort and improves record-keeping.

## Objectives

- Provide role-based login for Admin and Traffic Police.
- Let officers upload CCTV images/video and run AI detection on them.
- Detect vehicles, read number plates, and classify a violation type.
- Store violations in MongoDB and present them in searchable, filterable views.
- Generate printable/downloadable reports.

## Important: read this before your demo

Training a real helmet/seat-belt/red-light/speed violation detector needs labeled
datasets this project does not include. The AI service (`ai/main.py`) will use real
YOLO vehicle detection and EasyOCR plate reading **if you install those optional
libraries** (see `ai/requirements.txt`). If they are not installed, or cannot produce
a confident result, the service returns a clearly-labelled **simulated/demo result**
so the full workflow (upload → detect → save → report) still works end-to-end.
Every simulated record is tagged `isDemo: true` and shown with a "DEMO" badge or an
info banner in the UI — it is never presented as a genuine AI prediction.

## Features

- Admin / Traffic Police login with JWT authentication and hashed passwords
- Dashboard with stat cards, a violations-by-type pie chart, a 7-day trend line
  chart, and a recent-violations table
- Upload Footage page with drag-and-drop, progress states, and file-type validation
- AI Detection Result page showing the evidence image and extracted details
- Violations list with search, filters, pagination, view, and delete
- Violation Details page
- Vehicles page (aggregated from violation records)
- Reports page with print and CSV download
- Admin-only Users page
- Profile page
- Sample/demo data seeding so the dashboard is never empty

## Technology stack

| Layer     | Technology |
|-----------|------------|
| Frontend  | React 18, Vite, React Router, Axios, Bootstrap 5, Recharts |
| Backend   | Node.js, Express, Mongoose, JWT, bcryptjs, multer |
| Database  | MongoDB |
| AI        | Python, Flask, OpenCV, YOLO (ultralytics, optional), EasyOCR (optional) |

## Architecture

```
React (Vite, :5173)
      │  REST calls (Axios)
      ▼
Node/Express API (:5000) ──── MongoDB (violations, users)
      │  multipart file forward (axios + form-data)
      ▼
Python Flask AI service (:8000) ── OpenCV / YOLO / EasyOCR (or demo fallback)
```

The Node backend never calls MongoDB or the AI service directly from the browser;
the browser only talks to Express, and Express is the only thing that talks to
MongoDB and to the Python service. This keeps CORS and auth handling in one place.

## Folder structure

```
SmartTraffic/
├── client/                 React + Vite frontend
│   └── src/
│       ├── components/     Sidebar, Navbar, Layout, ProtectedRoute
│       ├── pages/          Login, Dashboard, UploadFootage, DetectionResults,
│       │                   Violations, ViolationDetails, Vehicles, Reports,
│       │                   Profile, Users
│       ├── context/        AuthContext (JWT + user in localStorage)
│       ├── services/       api.js (Axios instance)
│       └── styles/         theme.css
├── server/                 Express backend
│   ├── models/             User.js, Violation.js
│   ├── routes/              authRoutes, violationRoutes, dashboardRoutes,
│   │                        userRoutes, uploadRoutes
│   ├── controllers/        matching controllers for each route file
│   ├── middleware/         auth.js (JWT verification + role guard)
│   ├── seed.js             creates demo users + sample violations
│   └── server.js
├── ai/                      Python AI microservice
│   ├── main.py              Flask app, POST /detect
│   └── requirements.txt
├── README.md
└── .gitignore
```

## Database design

**User**: name, email (unique), password (bcrypt hash), role (`Admin` | `Traffic Police`), timestamps.

**Violation**: vehicleNumber, violationType (`No Helmet` | `No Seat Belt` | `Red Light` | `Over Speeding`),
vehicleType, date, time, location, confidence, evidenceImage, fineAmount,
status (`Pending` | `Paid` | `Disputed`), isDemo, timestamps.

## API endpoints

```
POST   /api/auth/register
POST   /api/auth/login

GET    /api/violations           (query: vehicleNumber, violationType, status, page, limit)
GET    /api/violations/:id
POST   /api/violations
PUT    /api/violations/:id
DELETE /api/violations/:id

GET    /api/dashboard/stats

GET    /api/users                (Admin only)
DELETE /api/users/:id            (Admin only)

POST   /api/upload                (multipart file → forwarded to the AI service)
```

All routes except `/api/auth/*` and `/api/health` require a `Bearer` JWT.

## AI explanation

`ai/main.py` runs a Flask server with one real endpoint, `POST /detect`:

1. Receives the uploaded file and saves it under `ai/uploads/`.
2. If it's a video, grabs the first frame with OpenCV for still-image analysis
   (documented as a limitation — full frame-by-frame video analysis is a future
   enhancement).
3. If `ultralytics` (YOLO) is installed, runs the pretrained `yolov8n.pt` model
   to detect a vehicle class (car/motorcycle/bus/truck).
4. If `easyocr` is installed, attempts to read the number plate text.
5. Picks a violation type. **A specialized violation-classifier model (helmet /
   seat-belt / red-light / speed) is out of scope for this project** — violation
   type is chosen from the supported list, and confidence/plate values fall back
   to realistic simulated numbers whenever real detection didn't produce them.
6. Returns JSON to the Node backend, which forwards it to the frontend and — on
   "SAVE VIOLATION" — stores it in MongoDB.

To go from demo to a stronger AI: replace the `run_vehicle_detection` /
`run_plate_ocr` logic with your own trained YOLO violation model, and enable
the optional dependencies in `ai/requirements.txt`.

## Prerequisites (Windows)

Open PowerShell or Command Prompt and check:

```
node -v
npm -v
python --version
pip --version
```

- If `node`/`npm` are missing: install Node.js LTS from https://nodejs.org
- If `python`/`pip` are missing: install Python 3.10+ from https://python.org
  (tick "Add python.exe to PATH" during install)
- Install MongoDB Community Server (https://www.mongodb.com/try/download/community)
  **or** create a free MongoDB Atlas cluster (https://www.mongodb.com/atlas) if you
  don't want to install MongoDB locally.

## Setup

Assume the project is unzipped to `C:\SmartTraffic`.

### 1. Backend

```
cd C:\SmartTraffic\server
npm install
copy .env.example .env
```

Edit `.env` and set `MONGO_URI` (local or Atlas connection string), then seed demo
data:

```
npm run seed
npm run dev
```

You should see:

```
Server running on port 5000
MongoDB connected successfully
```

### 2. AI service

Open a **new** terminal:

```
cd C:\SmartTraffic\ai
pip install -r requirements.txt
python main.py
```

You should see:

```
AI service running
```

(Real YOLO/EasyOCR detection is optional — uncomment `ultralytics` and `easyocr`
in `requirements.txt` and reinstall if you want it; otherwise the service uses
the documented demo fallback.)

### 3. Frontend

Open a **third** terminal:

```
cd C:\SmartTraffic\client
npm install
npm run dev
```

You should see a local URL:

```
Local:   http://localhost:5173/
```

### 4. Open the app

Open Chrome at `http://localhost:5173`, then log in.

## Demo credentials

Created automatically by `npm run seed` in `server/`:

| Role           | Email                     | Password  |
|----------------|---------------------------|-----------|
| Admin          | admin@smarttraffic.com    | Admin@123 |
| Traffic Police | police@smarttraffic.com   | Police@123|

## Demo flow (for your viva/demonstration)

1. Open `http://localhost:5173` → Login page.
2. Log in as Admin (see credentials above).
3. Dashboard shows stat cards, charts, and recent violations (seeded sample data).
4. Open **Upload Footage** from the sidebar.
5. Choose any JPG/PNG image (any traffic/vehicle photo works — no copyrighted
   material required; even a random photo will still exercise the full pipeline
   through the demo fallback).
6. Click **UPLOAD & DETECT** — watch the processing stages.
7. Review the AI Detection Result page (vehicle info, violation, confidence, fine).
8. Click **SAVE VIOLATION** — this writes to MongoDB.
9. Open **Violations** — the new record appears; try the search and filters.
10. Click **View** on a row to open **Violation Details**.
11. Open **Reports**, then **PRINT REPORT** or **DOWNLOAD REPORT**.
12. As Admin, open **Users** to show role-based access (Traffic Police cannot see this page).

## Error handling

- MongoDB unreachable at startup → server still starts and logs a clear warning;
  API calls that need the DB return a friendly error instead of crashing.
- AI service unreachable → `uploadRoutes.js` catches the failure and returns a
  clearly-labelled demo result instead of failing the request.
- OCR/YOLO can't read a file → `ai/main.py` catches the exception and returns the
  demo fallback.
- Invalid file type/size → rejected with a specific message on both frontend and
  backend (multer `fileFilter`).
- Invalid login → friendly "Invalid email or password" message, no stack traces.
- Backend down → the frontend Axios interceptor shows "Could not reach the backend
  server..." instead of a blank crash.

## Testing checklist

Manual test cases to run and record for your report:

1. Login with valid Admin credentials → redirected to dashboard.
2. Login with valid Traffic Police credentials → redirected to dashboard, Users
   link hidden.
3. Login with wrong password → friendly error shown.
4. Login with correct credentials but wrong role selected → friendly error shown.
5. Traffic Police tries to open `/users` directly → redirected away.
6. Upload a JPG image → processing stages shown → detection result appears.
7. Upload an MP4 video → first-frame extraction runs, result appears.
8. Upload a `.txt` file → rejected with an unsupported-file-type message.
9. Save a violation → appears at the top of the Violations list.
10. Search Violations by vehicle number → filtered results returned.
11. Filter Violations by violation type and by status.
12. Delete a violation → removed from the list and from MongoDB.
13. Dashboard stat cards and charts match the number of stored violations.
14. Open Reports → Print and CSV download both work.
15. Stop the AI service, upload a file → demo fallback response still returned,
    UI does not crash.
16. Stop MongoDB, load the dashboard → friendly error message shown.

## Limitations

- No custom-trained violation-classification model is included; violation type
  detection uses a documented, clearly-labelled demo fallback when a confident
  real result isn't available.
- Video analysis only inspects the first frame, not the full clip.
- Vehicles page aggregates from violation records rather than a dedicated
  Vehicle collection.
- Not hardened for production deployment (no rate limiting, no email
  verification, no refresh tokens).

## Future enhancements

- Train a custom YOLO model on a labeled helmet/seat-belt/red-light/speed dataset.
- Full video pipeline with frame sampling and tracking across frames.
- Automatic fine-payment integration.
- Email/SMS notifications to vehicle owners.
- Live CCTV stream ingestion instead of file upload only.

## Viva questions (sample)

1. **What does MERN stand for?** MongoDB, Express, React, Node.js.
2. **Why Express over plain Node http?** It gives routing, middleware, and JSON
   handling out of the box, reducing boilerplate.
3. **What is a REST API?** An architectural style using HTTP verbs (GET/POST/PUT/DELETE)
   on resource URLs to perform CRUD operations.
4. **What is Mongoose?** An ODM (Object Data Modeling) library that maps JS
   objects/schemas to MongoDB documents.
5. **Why store password hashes, not plain text?** So a database leak doesn't
   expose real passwords; bcrypt is a slow, salted hashing algorithm designed
   for this.
6. **What is JWT and why use it here?** A signed token containing user identity/
   role, sent with each request so the server can authenticate/authorize
   without server-side sessions.
7. **How is role-based access enforced?** The `requireRole` middleware checks
   `req.user.role` (decoded from the JWT) before allowing Admin-only routes.
8. **What is CORS and why did you enable it?** A browser security rule that
   blocks cross-origin requests by default; the `cors` middleware allows the
   frontend (port 5173) to call the backend (port 5000).
9. **What is React Router used for?** Client-side navigation between pages
   (Login, Dashboard, Violations, etc.) without full page reloads.
10. **What is Axios?** A promise-based HTTP client used to call the backend API
    from React.
11. **What is Vite, and why not Create React App?** A fast dev server/bundler
    using native ES modules; faster startup and hot-reload than CRA.
12. **What is YOLO?** "You Only Look Once" — a real-time object-detection model
    family that predicts bounding boxes and classes in a single pass.
13. **What is OpenCV used for here?** Reading images/video frames and basic
    image operations (e.g., extracting a video's first frame).
14. **What is OCR?** Optical Character Recognition — extracting text (the plate
    number) from an image.
15. **What is EasyOCR?** A ready-to-use, deep-learning-based OCR library
    supporting many languages, used here to attempt plate-text extraction.
16. **Why does the project have a "demo fallback"?** Real violation detection
    needs a trained model and labeled data this project doesn't have; the
    fallback keeps the workflow demonstrable and is clearly labelled, never
    claimed as real.
17. **How does Node talk to the Python service?** The Express upload route
    forwards the uploaded file over HTTP (multipart/form-data) to the Flask
    `/detect` endpoint using axios, and relays the JSON response.
18. **What happens if the AI service is down?** The Express route catches the
    request failure and returns a clearly-labelled simulated result instead of
    crashing.
19. **What is multer?** Node middleware for handling `multipart/form-data`
    (file uploads) in Express.
20. **How are violations stored?** As documents in a MongoDB `violations`
    collection via the Mongoose `Violation` model.
21. **What confidence value is shown, and what does it mean?** A 0-100 score;
    for real YOLO detections it's the model's class-probability, for demo
    results it's a simulated plausible value.
22. **How is pagination implemented?** The `/api/violations` route accepts
    `page`/`limit` query params and uses Mongoose `.skip()`/`.limit()`.
23. **What database design choice was made for "Vehicles"?** Rather than a
    separate collection, vehicle info is aggregated on the frontend from
    existing violation records, to keep the schema simple for this project's
    scope.
24. **What's a key limitation of this project?** No trained violation-specific
    computer-vision model; detection results can be simulated and are labelled
    as such.
25. **What would you improve given more time?** Train a real violation model,
    process full video streams, and add payment/notification integrations.

## PPT outline (12–15 slides)

1. Title slide — project name, your name, college, guide
2. Problem statement
3. Existing system vs proposed system
4. Objectives and scope
5. System architecture diagram (React ↔ Express ↔ MongoDB, Express ↔ Flask AI)
6. Technology stack
7. Modules overview (Auth, Dashboard, Upload/Detection, Violations, Reports, Users)
8. ER diagram / database design (User, Violation)
9. Login and role-based access — screenshot
10. Dashboard — screenshot
11. Upload → AI detection flow — screenshot
12. Violation result and save flow — screenshot
13. Violations list, details, and reports — screenshots
14. Limitations and the AI demo-fallback explanation
15. Future enhancements and conclusion

**5-minute script**: Introduce the problem (manual traffic monitoring is slow) →
walk through the architecture diagram → live-demo the flow from login to a saved,
reported violation → be upfront about the demo-fallback limitation and what a
production version would need → close with future enhancements.
